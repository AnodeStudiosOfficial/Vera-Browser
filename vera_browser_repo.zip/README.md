# Vera Secure Browser 🛡️

Askeri bölgeler ve okullar için tasarlanmış, sıfır iz bırakan (stateless), şifre kaydetmeyen ve merkezi olarak yönetilen güvenli tarayıcı konsepti ve çekirdek modülleri.

## 🚀 Özellikler
- **Stateless / Ephemeral Mode:** Disk üzerinde hiçbir tarama geçmişi, çerez veya önbellek bırakmaz; oturum kapatıldığında her şey RAM'den silinir.
- **Politika Motoru (`vera_policy.json`):** Yöneticiler için merkezi engelleme (blacklist) ve izin verme (whitelist) kuralları.
- **Sıfır Kimlik Doğrulama / Şifre Kilidi:** Şifre yöneticisi ve otomatik doldurma donanımsal/kod düzeyinde kapalıdır.

## 📂 Proje Yapısı
- `vera_policy.json`: Politika yapılandırma dosyası.
- `policy_engine.py`: URL denetim ve kural doğrulama motoru.
- `ephemeral_storage.py`: RAM tabanlı bellek izolasyonu ve imha mekanizması.
